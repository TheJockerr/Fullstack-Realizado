import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer"; // <-- agregado

// Páginas
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Ranking from "./pages/Ranking";
import Login from "./pages/Login";
import Account from "./pages/Account";
import Dashboard from "./pages/Dashboard";

export default function App() {
  return (
    <>

      {/* Navbar está aquí, visible en TODAS las páginas */}
      <Navbar />

      {/* Contenido de las rutas */}
      <Routes>

        {/* Redirect para que la ruta por defecto sea /home */}
        <Route path="/" element={<Navigate to="/home" />} />

        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/ranking" element={<Ranking />} />
        <Route path="/login" element={<Login />} />
        <Route path="/account" element={<Account />} />
        <Route path="/dashboard" element={<Dashboard />} />

      </Routes>

      {/* Footer agregado */}
      <Footer />
    </>
  );
}
