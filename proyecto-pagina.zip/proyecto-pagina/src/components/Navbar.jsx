import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { Link } from "react-router-dom";

export default function Navbar() {
  const { usuario } = useContext(AuthContext);

  return (
    <nav className="navbar">
      <Link to="/" className="brand">KDC</Link>

      <div className="navbar-links">
        <Link to="/Home">Inicio</Link>
        <Link to="/Ranking">Ranking</Link>
        <Link to="/Contact">Contacto</Link>
        <Link to="/About">Quiénes Somos</Link>

        {usuario ? (
          <Link className="btn-primary" to="/Account">
            Cuenta
          </Link>
        ) : (
          <Link className="btn-primary" to="/Login">
            Iniciar Sesión
          </Link>
        )}
      </div>
    </nav>
  );
}
