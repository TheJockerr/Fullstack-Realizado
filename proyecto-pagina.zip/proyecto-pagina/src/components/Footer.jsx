// src/components/Footer.jsx
import React from "react";

export default function Footer() {
  return (
    <footer id="footer">
      <div id="footer-content">
        <h2 id="footer-logo">KDC — Combate de Concepción</h2>

        <div id="footer-links">
          <a href="/Ranking">Ranking</a>
          <a href="/Contact">Contacto</a>
          <a href="/About">Quiénes Somos</a>
        </div>

        <p id="footer-copy">© 2025 KDC. Todos los derechos reservados.</p>
      </div>
    </footer>
  );
}
