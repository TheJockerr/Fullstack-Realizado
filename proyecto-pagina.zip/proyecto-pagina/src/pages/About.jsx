import React from "react";


export default function About() {
return (
<div className="page-container">
<h1>¿Quiénes Somos?</h1>
<p>KDC es un videojuego chileno inspirado en el combate urbano y la estrategia táctica.</p>
<p>Creado por desarrolladores apasionados por los videojuegos. MI JUEGO CHILENOUUUU</p>
</div>
);
}