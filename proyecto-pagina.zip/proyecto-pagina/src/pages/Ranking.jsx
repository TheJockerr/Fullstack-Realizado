import { useEffect, useState, useContext } from "react";
import { obtenerRanking } from "../api/usuarioService";
import { AuthContext } from "../context/AuthContext";

export default function RankingPage() {
  const { usuario } = useContext(AuthContext);

  const [ranking, setRanking] = useState([]);
  const [posicionUsuario, setPosicionUsuario] = useState(null);

  useEffect(() => {
    obtenerRanking().then((data) => {
      setRanking(data);

      if (usuario) {
        const index = data.findIndex((u) => u.id === usuario.id);
        setPosicionUsuario(index !== -1 ? index + 1 : null);
      }
    });
  }, [usuario]);

  return (
    <div id="ranking-page">

      {/* 🔵 CARD CUANDO EL USUARIO NO ESTÁ LOGUEADO */}
      {!usuario && (
        <div id="ranking-login-card">
          <h2>¿Quieres ver tu posición en el ranking?</h2>
          <p>Inicia sesión para ver tu puntaje y comparar con otros jugadores.</p>
          <a id="ranking-login-btn" href="/login">
  Iniciar Sesión
</a>

        </div>
      )}

      {/* 🟢 CARD CUANDO EL USUARIO ESTÁ LOGUEADO */}
      {usuario && posicionUsuario && (
        <div id="ranking-user-card">
          <h2>Tu Puesto en el Ranking</h2>

          <p id="ranking-user-position">
            <strong>#{posicionUsuario}</strong> — {usuario.username}
          </p>

          <p id="ranking-user-score">
            Puntaje: <strong>{usuario.puntaje}</strong>
          </p>
        </div>
      )}

      {/* 🏆 LISTA DE RANKING GLOBAL */}
      <div id="ranking-global-card">
        <h1>Ranking Global</h1>

        {ranking.map((u, i) => {
          const esUsuarioActivo = usuario && usuario.id === u.id;

          return (
            <div
              key={u.id}
              className={`ranking-item ${esUsuarioActivo ? "ranking-item-active" : ""}`}
            >
              <span>#{i + 1}</span>
              <strong>{u.username}</strong>
              <span>{u.puntaje} pts</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
