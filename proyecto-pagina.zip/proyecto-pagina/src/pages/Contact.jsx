import React from "react";

export default function Contact() {
  return (
    <div className="page-container">
    
    <div class="contacto-card">
      <h1>Contacto</h1>
      <p><strong>Email:</strong> contacto@kdc.com</p>
      <p><strong>Discord:</strong> KDC Oficial</p>
      <p><strong>Dirección:</strong> Concepción, Chile</p>
        </div>

    <div class="contacto-card">
      <h2 style={{ marginTop: "25px", color: "#4da3ff" }}>Soporte</h2>
      <p>
        ¿Tienes dudas, problemas con tu cuenta o sugerencias para mejorar la plataforma?
        Nuestro equipo está disponible para ayudarte.
      </p>
      </div>

    <div class="contacto-card">
      <h2 style={{ marginTop: "25px", color: "#4da3ff" }}>Horario de Atención</h2>
      <ul>
        <li>Lunes a Viernes: 10:00 - 18:00</li>
        <li>Sábados: 10:00 - 14:00</li>
        <li>Domingos y festivos: Cerrado</li>
      </ul>
    </div>


    <div class="contacto-card">
      <h2 style={{ marginTop: "25px", color: "#4da3ff" }}>Redes Sociales</h2>
      <p>Síguenos para enterarte de eventos, actualizaciones y noticias:</p>
      <ul>
        <li>Instagram: @kdc_oficial</li>
        <li>Tiktok: @kdc_clips</li>
        <li>Youtube: KDC eSports</li>
      </ul>
      </div>
    </div>
  );
}
