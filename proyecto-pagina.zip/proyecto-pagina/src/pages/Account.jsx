import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function Account() {
  const { logout, usuario } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();              // Limpia el usuario del contexto
    navigate("/login");    // Redirige al login
  };

  return (
    <div id="account-page">
      <div id="account-card">
        <h1 id="account-title">Gestión de Cuenta</h1>
        <p id="account-text">Bienvenido, <strong>{usuario?.username}</strong></p>

        <button id="logout-btn" onClick={handleLogout}>
          Cerrar Sesión
        </button>
      </div>
    </div>
  );
}
