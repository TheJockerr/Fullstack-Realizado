import React from "react";
export default function Home() {
return (
<div className="home-hero">
<h1 className="home-title">Combate de Concepción</h1>
<p className="home-subtitle">El videojuego táctico más explosivo inspirado en la ciudad.</p>
<a className="btn-primary" href="/ranking">Ver Ranking</a>
</div>
);
}