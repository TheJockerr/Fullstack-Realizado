import { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const [username, setUser] = useState("");
  const [password, setPass] = useState("");

  const [showPopup, setShowPopup] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();

    const res = await fetch("http://localhost:8081/api/usuarios/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });

    if (!res.ok) {
      setShowPopup(true);
      return;
    }

    const data = await res.json();

    login(data);
    navigate("/account");
  };

  return (
    <>
      {showPopup && (
        <div id="popup-overlay">
          <div id="popup-box">
            <h2>Credenciales incorrectas</h2>
            <p>El usuario o contraseña no coinciden.</p>
            <button id="popup-btn" onClick={() => setShowPopup(false)}>
              Aceptar
            </button>
          </div>
        </div>
      )}

      <div id="login-container">
        <form id="login-box" onSubmit={handleLogin}>
          <h1 id="login-title">Iniciar Sesión</h1>

          <input
            id="login-input-user"
            placeholder="Usuario"
            value={username}
            onChange={(e) => setUser(e.target.value)}
          />

          <input
            id="login-input-pass"
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPass(e.target.value)}
          />

          <button id="login-btn">Ingresar</button>

          {/* 🔵 NUEVO BOTÓN DE REGISTRO */}
          <button
            id="login-create-btn"
            type="button"
            onClick={() => navigate("/registro")}
          >
            Crear Cuenta
          </button>
        </form>
      </div>
    </>
  );
}
