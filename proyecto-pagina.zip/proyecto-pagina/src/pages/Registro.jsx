import { useState } from "react"; 
import { registrarUsuario } from "../api/ApiUser";
import { useNavigate } from "react-router-dom";

export default function Registro() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    nombre: "",
    email: "",
    password: "",
  });

  const [popup, setPopup] = useState({
    visible: false,
    mensaje: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await registrarUsuario(form);

      setPopup({
        visible: true,
        mensaje: "Registro exitoso. Redirigiendo a tu cuenta...",
      });

      // ⬅️ Redirigir automáticamente después de 1.5s
      setTimeout(() => {
        navigate("/account");
      }, 1500);

    } catch (err) {
      setPopup({
        visible: true,
        mensaje: "Error al registrar. Intenta nuevamente.",
      });
    }
  };

  return (
    <div className="registro-container">

      <h2 className="registro-title">Crear Cuenta</h2>

      <form onSubmit={handleSubmit} className="registro-form">

        <label>Nombre</label>
        <input
          type="text"
          name="nombre"
          value={form.nombre}
          onChange={handleChange}
          required
        />

        <label>Correo electrónico</label>
        <input
          type="email"
          name="email"
          value={form.email}
          onChange={handleChange}
          required
        />

        <label>Contraseña</label>
        <input
          type="password"
          name="password"
          value={form.password}
          onChange={handleChange}
          required
        />

        <button className="btn-primary" type="submit">
          Registrarse
        </button>

      </form>

      {/* POPUP */}
      {popup.visible && (
        <div className="popup-overlay">
          <div className="popup">
            <p>{popup.mensaje}</p>
            <button
              className="btn-primary"
              onClick={() => setPopup({ ...popup, visible: false })}
            >
              Aceptar
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
