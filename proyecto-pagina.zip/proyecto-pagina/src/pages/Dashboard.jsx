import React, { useEffect, useState } from "react";


export default function Dashboard() {
const [stats, setStats] = useState(null);


useEffect(() => {
setStats({ partidas: 15, victorias: 7, derrotas: 8 });
}, []);


return (
<div className="page-container">
<h1>Dashboard</h1>
{!stats ? <p>Cargando...</p> : <pre>{JSON.stringify(stats, null, 2)}</pre>}
</div>
);}