import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { AuthProvider } from "./context/AuthContext";
import "./styles/global.css"; 

ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <AuthProvider>
      <App />
    </AuthProvider>
  </BrowserRouter>
);
//browser router es el que se encarga de manejar las rutas en la aplicación, y el auth provider es el que se encarga de manejar la autenticación de los usuarios.
//hash router es una variante de browser router que utiliza el hash de la URL para manejar las rutas, lo cual es útil en aplicaciones que se sirven desde un servidor estático o que no tienen soporte para rutas del lado del servidor.