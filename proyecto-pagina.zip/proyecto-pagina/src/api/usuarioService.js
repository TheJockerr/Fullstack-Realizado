import API_URL from "./Api.js";

// REGISTER
export async function registrarUsuario(data) {
  const res = await fetch(`${API_URL}/registro`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  if (!res.ok) throw new Error("Error al registrar");
  return res.json();
}

// LOGIN
export async function login(data) {
  const res = await fetch(`${API_URL}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  if (!res.ok) throw new Error("Credenciales incorrectas");
  return res.json();
}

// RANKING GLOBAL
export async function obtenerRanking() {
  const res = await fetch(`${API_URL}/ranking`);
  if (!res.ok) throw new Error("Error obteniendo ranking");
  return res.json();
}

// ACTUALIZAR PUNTAJE
export async function actualizarPuntaje(id, puntaje) {
  const res = await fetch(`${API_URL}/${id}/puntaje?puntaje=${puntaje}`, {
    method: "PUT",
  });

  if (!res.ok) throw new Error("Error al actualizar puntaje");
  return res.json();
}
