const API_URL = "http://localhost:8081/api/usuarios";

export default API_URL;
